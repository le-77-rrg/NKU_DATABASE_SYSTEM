from flask import Flask, request, render_template, redirect, session, url_for,flash,jsonify
import mysql.connector
import traceback

app = Flask(__name__)
app.secret_key = 'a9d4f6c3e1b8e927f4c0a12d8792bf8c'

# 数据库配置
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': 'password123',  # MySQL 密码
    'database': 'shopping_order'  # 数据库名称
}

@app.route('/')
def index():
    return redirect('/login')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        userid = request.form['userid']
        password = request.form['password']
        conn = None
        cursor = None

        try:
            # 清理旧 session（防止登录后未清除上一个用户）
            session.clear()

            conn = mysql.connector.connect(**db_config)
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT * FROM Users WHERE UserID = %s AND Password = %s", (userid, password))
            user = cursor.fetchone()

            if user:
                # 写入 session，支持多用户并发登录
                session['userid'] = user['UserID']
                session['username'] = user['UserName']
                session['role'] = user['Role']

                # 如果是商家，还需判断是否激活
                if user['Role'] == 'merchant':
                    cursor.execute("SELECT IsActive FROM Merchants WHERE UserID = %s", (userid,))
                    merchant = cursor.fetchone()
                    if merchant and not merchant['IsActive']:
                        session.clear()
                        return render_template('login.html', error="商家账号尚未激活，请等待管理员审核。")

                # 登录成功，根据角色跳转
                if user['Role'] == 'admin':
                    return redirect('/admin')
                elif user['Role'] == 'merchant':
                    return redirect('/merchant')
                else:
                    return redirect('/user')

            else:
                return render_template('login.html', error="用户名或密码错误")

        except Exception as e:
            return render_template('login.html', error=f"登录出错: {e}")

        finally:
            if cursor:
                cursor.close()
            if conn:
                conn.close()

    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        userid = request.form['userid']
        username = request.form['username']
        phone = request.form['phone']
        password = request.form['password']
        role = request.form['role']

        if role == 'admin':
            return "不能注册管理员账户"

        try:
            conn = mysql.connector.connect(**db_config)
            cursor = conn.cursor()
            sql = "INSERT INTO Users (UserID, UserName, Phone, Password, Role) VALUES (%s, %s, %s, %s, %s)"
            values = (userid, username, phone, password, role)
            cursor.execute(sql, values)
            if role == 'merchant':
                cursor.execute(
                    "INSERT INTO Merchants (UserID, IsActive, LicenseNo) VALUES (%s, FALSE, NULL)",
                    (userid,)
                )

            conn.commit()
            cursor.close()
            conn.close()
            return redirect('/login')
        except Exception as e:
            return f"发生错误: {e}"

    return render_template('register.html')

@app.route('/admin')
def admin_dashboard():
    if session.get('role') != 'admin':
        return jsonify({"success": False, "message": "权限不足，请先登录"})
    return render_template('admin_dashboard.html', username=session.get('username'))

@app.route('/user')
def user_dashboard():
    if session.get('role') != 'user':
        return jsonify({"success": False, "message": "权限不足，请先登录"})
    return render_template('user_dashboard.html', username=session.get('username'))

@app.route('/merchant', methods=['GET'])
def merchant_dashboard():
    if session.get('role') != 'merchant':
        return jsonify({"success": False, "message": "权限不足，请先登录"})

    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM ProductRequests WHERE UserID = %s", (session.get('userid'),))
        requests = cursor.fetchall()
        cursor.close()
        conn.close()

        return render_template('merchant_dashboard.html', username=session.get('username'), requests=requests, success=True)
    except Exception as e:
        return jsonify({"success": False, "message": f"发生错误: {e}"})

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/login')


@app.route('/merchant/add_product', methods=['POST'])
def add_product():
    if session.get('role') != 'merchant':
        return jsonify({"success": False, "message": "权限不足"})

    try:
        # 获取表单数据
        product_id = request.form.get('product_id')
        product_name = request.form.get('product_name')
        price = request.form.get('price')
        product_type = request.form.get('product_type')
        condition = 'pending'
        user_id = session.get('userid')

        # 初始化各字段
        stock = stock_limits = release_time = design_notes = due_date = None

        # 解析不同类型商品的附加字段
        if product_type == 'standard':
            stock = int(request.form['stock'])  # 转换为 int
        elif product_type == 'limited':
            stock_limits = int(request.form['stock_limits'])
            release_time = request.form['release_time']  # 保持字符串，MySQL 可接收 YYYY-MM-DD
        elif product_type == 'custom':
            design_notes = request.form['design_notes']
            due_date = request.form['due_date']

        # 建立数据库连接
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor(buffered=True)

        # 获取管理员 UserID（假设系统只有一个管理员）
        cursor.execute("SELECT UserID FROM admins LIMIT 1")
        admin_row = cursor.fetchone()
        if not admin_row:
            return jsonify({"success": False, "message": "没有找到管理员账号，无法提交请求。"})

        admin_userid = admin_row[0]

        # 检查是否已存在该 ProductID 的产品
        cursor.execute("SELECT * FROM Products WHERE ProductID = %s", (product_id,))
        existing_product = cursor.fetchone()
        if existing_product:
            return jsonify({"success": False, "message": "该商品ID已存在，请更换商品ID。"})

        # 检查是否已存在该 ProductID 的“待审核添加”请求
        cursor.execute("""
            SELECT * FROM ProductRequests 
            WHERE ProductID = %s AND Type = 'add' AND Status = 'pending'
        """, (product_id,))
        existing_request = cursor.fetchone()
        if existing_request:
            return jsonify({"success": False, "message": "已有相同商品ID的添加请求，不能重复提交"})


        # 插入请求记录
        print("准备插入商品请求记录...")
        cursor.execute("""
            INSERT INTO ProductRequests 
            (ProductID, UserID, Adm_UserID, Type, Status, ProductType, ProductName, Price, Stock, StockLimits, ReleaseTime, DesignNotes, DueDate) 
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """, (
            product_id, user_id, admin_userid, 'add', condition,
            product_type, product_name, price, 
            stock, stock_limits, release_time, design_notes, due_date
        ))
        conn.commit()
        print("插入成功，事务提交完成。")

        return jsonify({
            "success": True,
            "message": "商品添加请求已提交",
            "request_id": cursor.lastrowid
        })

    except Exception as e:
        conn.rollback()
        print("错误堆栈详情：")
        print(traceback.format_exc())
        return jsonify({"success": False, "message": f"发生错误: {e}"})

    finally:
        cursor.close()
        conn.close()

@app.route('/merchant/delete_product/<product_id>', methods=['GET'])
def delete_product(product_id):
    if session.get('role') != 'merchant':
        return jsonify({"success": False, "message": "权限不足"})

    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor(dictionary=True)

        # 获取商家ID
        merchant_id = session['userid']

        # 检查是否已有待审核的“delete”请求
        cursor.execute("""
            SELECT * FROM ProductRequests 
            WHERE ProductID = %s AND Type = 'delete' AND Status = 'pending'
        """, (product_id,))
        existing_request = cursor.fetchone()

        if existing_request:
            cursor.close()
            conn.close()
            return jsonify({"success": False, "message": "该商品已存在待审核的下架请求，无法重复提交。"})
        
        # 查询商品的详细信息
        cursor.execute("""
            SELECT p.*, 
                s.Stock, 
                l.StockLimits, l.ReleaseTime,
                c.DesignNotes, c.DueDate
            FROM Products p
            LEFT JOIN StandardProducts s ON p.ProductID = s.ProductID
            LEFT JOIN LimitedProducts l ON p.ProductID = l.ProductID
            LEFT JOIN CustomProducts c ON p.ProductID = c.ProductID
            WHERE p.ProductID = %s AND p.UserID = %s
        """, (product_id, merchant_id))
        product = cursor.fetchone()

        if not product:
            cursor.close()
            conn.close()
            return jsonify({"success": False, "message": "商品不存在或无权删除。"})

        # 插入删除请求到 ProductRequests 表
        cursor.execute("""
            INSERT INTO ProductRequests
            (ProductID, UserID, Adm_UserID, Type, Status, ProductType, ProductName, Price, Stock, StockLimits, ReleaseTime, DesignNotes, DueDate)
            VALUES (%s, %s, %s, 'delete', 'pending', %s, %s, %s, %s, %s, %s, %s, %s)
        """, (
            product_id, merchant_id, 'admin001',
            product['Category'], product['ProductName'], product['Price'],product['Stock'],
            product['StockLimits'], product['ReleaseTime'], product['DesignNotes'], product['DueDate']
        ))
        conn.commit()
        return jsonify({"success": True, "message": "下架请求已提交，等待管理员审核。"})
    
    except Exception as e:
        return jsonify({"success": False, "message": f"发生错误: {e}"})

    finally:
        cursor.close()
        conn.close()
@app.route('/merchant/get_product/<product_id>')
def get_product(product_id):
    if session.get('role') != 'merchant':
        return jsonify({"success": False, "message": "权限不足"})
    
    merchant_id = session['userid']
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor(dictionary=True)
    
    try:
        # 修改查询语句，确保日期格式正确
        cursor.execute("""
            SELECT *
            FROM v_product_details
            WHERE ProductID = %s AND UserID = %s
        """, (product_id, merchant_id))
        
        product = cursor.fetchone()
        
        if not product:
            return jsonify({"success": False, "message": "商品不存在或无权访问"})
        
        # 格式化日期
        if product.get('ReleaseTime'):
            product['ReleaseTime'] = str(product['ReleaseTime'])
        if product.get('DueDate'):
            product['DueDate'] = str(product['DueDate'])
            
        return jsonify(product)
    
    except Exception as e:
        return jsonify({"success": False, "message": f"获取商品信息失败: {str(e)}"})
    
    finally:
        cursor.close()
        conn.close()


@app.route('/merchant/update_product/<product_id>', methods=['GET', 'POST'])
def update_product(product_id):
    if 'userid' not in session or session['role'] != 'merchant':
        return jsonify({"success": False, "message": "权限不足"})

    conn = None
    cursor = None
    merchant_id = session['userid']

    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor(dictionary=True)

        # 获取管理员ID
        cursor.execute("SELECT UserID FROM admins LIMIT 1")
        admin = cursor.fetchone()
        if not admin:
            flash("未找到管理员账户")
            return redirect('/merchant/my_products')
        admin_id = admin['UserID']

        # 查询商品完整信息
        cursor.execute("""
            SELECT p.*, 
                s.Stock, 
                l.StockLimits, l.ReleaseTime,
                c.DesignNotes, c.DueDate
            FROM Products p
            LEFT JOIN StandardProducts s ON p.ProductID = s.ProductID
            LEFT JOIN LimitedProducts l ON p.ProductID = l.ProductID
            LEFT JOIN CustomProducts c ON p.ProductID = c.ProductID
            WHERE p.ProductID = %s AND p.UserID = %s
        """, (product_id, merchant_id))
        product = cursor.fetchone()

        if not product:
            flash("商品不存在或权限不足")
            return redirect('/merchant/my_products')

        if request.method == 'POST':
            # 检查是否已有待审核请求
            cursor.execute("""
                SELECT * FROM ProductRequests 
                WHERE ProductID = %s AND Type = 'update' AND Status = 'pending'
            """, (product_id,))
            if cursor.fetchone():
                return jsonify({"success": False, "message": "该商品已有待审核的更新请求"})

            # 收集更新数据
            update_data = {
                'ProductName': request.form['ProductName'],
                'Price': float(request.form['Price']),
                'Stock': request.form.get('Stock'),
                'StockLimits': request.form.get('StockLimits'),
                'ReleaseTime': request.form.get('ReleaseTime'),
                'DesignNotes': request.form.get('DesignNotes'),
                'DueDate': request.form.get('DueDate')
            }

            # 插入更新请求
            cursor.execute("""
                INSERT INTO ProductRequests (
                    ProductID, UserID, Adm_UserID, Type, Status, ProductType,
                    ProductName, Price, Stock, StockLimits, ReleaseTime, DesignNotes, DueDate
                ) VALUES (%s, %s, %s, 'update', 'pending', %s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                product_id, 
                merchant_id,
                admin_id,
                product['Category'],
                update_data['ProductName'],
                update_data['Price'],
                update_data['Stock'],
                update_data['StockLimits'],
                update_data['ReleaseTime'],
                update_data['DesignNotes'],
                update_data['DueDate']
            ))
            conn.commit()
            return jsonify({"success": True, "message": "更新请求已提交，等待管理员审核"})

    except Exception as e:
        return jsonify({"success": False, "message": f"更新出错: {str(e)}"})
    finally:
        if cursor: cursor.close()
        if conn: conn.close()

# 商家获取订单数据
@app.route('/merchant/api/orders')
def merchant_orders():
    if 'userid' not in session or session.get('role') != 'merchant':  # 修改 user_id 为 userid
        return jsonify({"error": "未授权访问"}), 403
    
    merchant_id = session.get('userid')  # 修改 user_id 为 userid
    
    try:
        conn = mysql.connector.connect(**db_config)  # 使用正确的数据库连接
        cursor = conn.cursor(dictionary=True)
        
        # 查询该商家的所有订单
        cursor.execute("""
            SELECT o.OrderID, o.UserID, o.ProductID, p.ProductName, o.Status, 
                   o.Quantity, o.TotalPrice, o.OrderTime
            FROM Orders o
            JOIN Products p ON o.ProductID = p.ProductID
            WHERE p.UserID = %s
            ORDER BY o.OrderTime DESC
        """, (merchant_id,))
        
        orders = cursor.fetchall()
        
        # 格式化日期时间
        for order in orders:
            if order['OrderTime']:
                order['OrderTime'] = order['OrderTime'].strftime('%Y-%m-%d %H:%M:%S')
        
        return jsonify(orders)
    
    except Exception as e:
        print(f"Error fetching merchant orders: {e}")
        return jsonify({"error": "获取订单数据失败"}), 500
    
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()

@app.route('/merchant/relist_product/<product_id>', methods=['GET'])
def relist_product(product_id):
    if session.get('role') != 'merchant':
        return jsonify({"success": False, "message": "权限不足"})

    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor(dictionary=True)

        merchant_id = session['userid']

        # 检查商品是否存在于Products表中
        cursor.execute("""
            SELECT * FROM Products 
            WHERE ProductID = %s AND UserID = %s
        """, (product_id, merchant_id))
        product = cursor.fetchone()
        
        if not product:
            return jsonify({"success": False, "message": "未找到该商品，无法重新上架。"})

        # 是否已有"待审核（上架）"请求
        cursor.execute("""
            SELECT * FROM ProductRequests
            WHERE ProductID = %s AND UserID = %s AND Type = 'add' AND Status = 'pending'
        """, (product_id, merchant_id))
        if cursor.fetchone():
            return jsonify({"success": False, "message": "该商品已有上架请求在审核中，请勿重复提交。"})

        # 获取最近一次的商品信息（从 ProductRequests 表中）
        cursor.execute("""
            SELECT * FROM ProductRequests
            WHERE ProductID = %s AND UserID = %s
            ORDER BY RequestID DESC
            LIMIT 1
        """, (product_id, merchant_id))
        last_request = cursor.fetchone()

        if not last_request:
            return jsonify({"success": False, "message": "未找到该商品的历史记录，无法重新上架。"})

        # 获取管理员 ID
        cursor.execute("SELECT UserID FROM admins LIMIT 1")
        admin = cursor.fetchone()
        if not admin:
            return jsonify({"success": False, "message": "未找到管理员账户，无法提交请求。"})
        
        admin_id = admin['UserID']

        # 插入"重新上架"请求（类型仍为 'add'）
        cursor.execute("""
            INSERT INTO ProductRequests 
            (ProductID, UserID, Adm_UserID, Type, Status, ProductType, ProductName, Price, Stock, StockLimits, ReleaseTime, DesignNotes, DueDate)
            VALUES (%s, %s, %s, 'add', 'pending', %s, %s, %s, %s, %s, %s, %s, %s)
        """, (
            product_id,
            merchant_id,
            admin_id,
            last_request['ProductType'],
            last_request['ProductName'],
            last_request['Price'],
            last_request['Stock'],
            last_request['StockLimits'],
            last_request['ReleaseTime'],
            last_request['DesignNotes'],
            last_request['DueDate']
        ))

        # 更新商品状态为激活（如果数据库有IsActive字段）
        cursor.execute("""
            UPDATE Products 
            SET IsActive = 1 
            WHERE ProductID = %s
        """, (product_id,))

        conn.commit()
        return jsonify({"success": True, "message": "商品重新上架请求已提交，等待管理员审核。"})

    except Exception as e:
        return jsonify({"success": False, "message": f"发生错误: {e}"})

    finally:
        cursor.close()
        conn.close()

def get_next_request_id(cursor):
    """生成下一个请求ID，这里简单生成一个递增的ID，具体实现可以根据实际需要调整"""
    cursor.execute("SELECT MAX(CAST(RequestID AS UNSIGNED)) FROM ProductRequests")
    max_request_id = cursor.fetchone()[0]
    return max_request_id + 1 if max_request_id else 1

@app.route('/merchant/messages')
def merchant_messages():
    user_id = session.get('userid')
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor(dictionary=True)

    try:
        cursor.execute("""
            SELECT ProductName, Type, Status, ProductType
            FROM ProductRequests
            WHERE UserID = %s
            ORDER BY RequestID DESC
        """, (user_id,))
        return jsonify(cursor.fetchall())
    except Exception as e:
        print(f"加载商家消息失败：{e}")
        return jsonify([])
    finally:
        cursor.close()
        conn.close()

@app.route('/merchant/my_products')
def merchant_my_products():
    if session.get('role') != 'merchant':
        return jsonify([])

    merchant_id = session['userid']
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor(dictionary=True)

    try:
        final_products = []

        # 获取该商家所有提交过的商品请求（每个商品只取最新一条）
        cursor.execute("""
            SELECT pr.*
            FROM ProductRequests pr
            INNER JOIN (
                SELECT ProductID, MAX(RequestID) AS MaxRequestID
                FROM ProductRequests
                WHERE UserID = %s
                GROUP BY ProductID
            ) latest ON pr.ProductID = latest.ProductID AND pr.RequestID = latest.MaxRequestID
            WHERE pr.UserID = %s
        """, (merchant_id, merchant_id))

        latest_requests = cursor.fetchall()

        for req in latest_requests:
            product_id = req['ProductID']
            name = req['ProductName']
            price = req['Price']
            ptype = req['ProductType']
            status = req['Status']
            rtype = req['Type']

            # 状态解释
            if status == 'approved':
                if rtype == 'add':
                    status_text = '已上架'
                elif rtype == 'delete':
                    status_text = '已下架'
                else:
                    status_text = '已上架（更新）'
            elif status == 'pending':
                if rtype == 'add':
                    status_text = '待审核（上架）'
                elif rtype == 'delete':
                    status_text = '待审核（下架）'
                elif rtype == 'update':
                    status_text = '待审核（更新）'
                else:
                    status_text = '待审核'
            elif status == 'rejected':
                if rtype == 'add':
                    status_text = '已下架（上架被拒绝）'
                elif rtype == 'delete':
                    status_text = '已上架（下架被拒绝）'
                else:
                    status_text = '已上架（更新被拒绝）'
            else:
                status_text = status

            final_products.append({
                'ProductID': product_id,
                'ProductName': name,
                'Price': price,
                'ProductType': ptype,
                'Status': status_text
            })

        return jsonify(final_products)

    finally:
        cursor.close()
        conn.close()

@app.route('/user/place_order', methods=['POST'])
def place_order():
    if session.get('role') != 'user':
        return jsonify({"success": False, "message": "权限不足"})
        
    product_id = request.form.get('product_id')
    user_id = session.get('userid')
    
    # 更健壮的处理方式
    try:
        quantity = int(request.form.get('quantity', 1))
    except (ValueError, TypeError):
        quantity = 1  # 如果转换失败，默认为1
    
    if not product_id:
        return jsonify({"success": False, "message": "请选择商品"})
        
    if quantity <= 0:
        return jsonify({"success": False, "message": "商品数量必须大于0"})
    
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor(dictionary=True)
    
    try:
        # 查询商品信息
        cursor.execute("""
            SELECT p.*, 
                   CASE 
                       WHEN p.Category = 'standard' THEN s.Stock
                       WHEN p.Category = 'limited' THEN l.StockLimits
                       ELSE NULL
                   END AS AvailableStock,
                   s.Stock, 
                   l.StockLimits, 
                   l.ReleaseTime,
                   c.DesignNotes, 
                   c.DueDate
            FROM Products p
            LEFT JOIN StandardProducts s ON p.ProductID = s.ProductID
            LEFT JOIN LimitedProducts l ON p.ProductID = l.ProductID
            LEFT JOIN CustomProducts c ON p.ProductID = c.ProductID
            WHERE p.ProductID = %s AND p.IsActive = 1
        """, (product_id,))
        
        product = cursor.fetchone()
        
        if not product:
            return jsonify({"success": False, "message": "商品不存在或已下架"})
        
        # 检查库存（如果是标准商品）  这里改成用触发器了
        # if product['Category'] == 'standard' and product['Stock'] is not None:
        #     if product['Stock'] < quantity:
        #         return jsonify({"success": False, "message": "库存不足"})
        
        # 检查限量商品的库存限制
        if product['Category'] == 'limited' and product['StockLimits'] is not None:
            # 查询已经卖出的数量
            cursor.execute("""
                SELECT SUM(Quantity) as sold
                FROM Orders
                WHERE ProductID = %s
            """, (product_id,))
            
            sold_result = cursor.fetchone()
            sold_count = sold_result['sold'] if sold_result['sold'] else 0
            
            if quantity > product['StockLimits']:
                return jsonify({"success": False, "message": "超出限量商品的限制数量"})
        
        # 生成订单ID（简单实现，实际应用中可能需要更复杂的逻辑）
        import uuid
        order_id = f"ORD-{uuid.uuid4().hex[:12].upper()}"
        
        # 计算总价
        total_price = product['Price'] * quantity
        
        # 创建订单
        cursor.execute("""
            INSERT INTO Orders (OrderID, UserID, ProductID, Quantity, TotalPrice, Status, OrderTime)
            VALUES (%s, %s, %s, %s, %s, %s, NOW())
        """, (order_id, user_id, product_id, quantity, total_price, '已下单'))
        
        # 如果是标准商品，更新库存
        # if product['Category'] == 'standard' and product['Stock'] is not None:
        #     cursor.execute("""
        #         UPDATE StandardProducts
        #         SET Stock = Stock - %s
        #         WHERE ProductID = %s
        #     """, (quantity, product_id))

        # 如果是限量商品，更新库存限制
        if product['Category'] == 'limited' and product['StockLimits'] is not None:
            cursor.execute("""
                UPDATE LimitedProducts
                SET StockLimits = StockLimits - %s
                WHERE ProductID = %s
            """, (quantity, product_id))
        
        conn.commit()
        
        return jsonify({
            "success": True, 
            "message": "下单成功", 
            "order_id": order_id
        })
    
    except Exception as e:
        conn.rollback()
        return jsonify({"success": False, "message": f"下单失败: {str(e)}"})
    
    finally:
        cursor.close()
        conn.close()
@app.route('/user/cancel_order', methods=['POST'])
def cancel_order():
    if session.get('role') != 'user':
        return jsonify({"success": False, "message": "权限不足"})
        
    order_id = request.form.get('order_id')
    product_id = request.form.get('product_id')
    quantity = int(request.form.get('quantity', 0))  # 确保转换为整数
    
    # 调试输出，检查是否正确接收到参数
    print(f"取消订单: 订单ID={order_id}, 商品ID={product_id}, 数量={quantity}")
    
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()
    
    try:
        # 更新订单状态
        cursor.execute("UPDATE Orders SET Status = 'cancelled' WHERE OrderID = %s", (order_id,))
        
        # 检查商品类型并更新库存
        cursor.execute("SELECT Category FROM Products WHERE ProductID = %s", (product_id,))
        product = cursor.fetchone()
        
        if product and product[0] == 'standard':
            # 标准商品需要更新库存
            cursor.execute("UPDATE StandardProducts SET Stock = Stock + %s WHERE ProductID = %s", (quantity, product_id))
            print(f"更新库存: 商品ID={product_id}, 增加数量={quantity}")
        if product and product[0] == 'limited':
            # 限量商品需要更新库存
            cursor.execute("UPDATE LimitedProducts SET StockLimits = StockLimits + %s WHERE ProductID = %s", (quantity, product_id))
            print(f"更新库存: 商品ID={product_id}, 增加数量={quantity}")
        # 提交事务
        conn.commit()
        
        return jsonify({"success": True})
    except Exception as e:
        conn.rollback()
        print(f"取消订单错误: {e}")
        return jsonify({"success": False, "message": str(e)})
    finally:
        cursor.close()
        conn.close()
        
@app.route('/user/api/products')
def user_api_products():
    if session.get('role') != 'user':
        return jsonify({"success": False, "message": "权限不足"})
        
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor(dictionary=True)
    
    try:
        # 查询所有上架的商品，包含库存信息
        cursor.execute("""
            SELECT p.ProductID, p.ProductName, p.Price, p.Category,
                   CASE 
                       WHEN p.Category = 'standard' THEN s.Stock
                       WHEN p.Category = 'limited' THEN l.StockLimits
                       ELSE NULL
                   END AS AvailableStock
            FROM Products p
            LEFT JOIN StandardProducts s ON p.ProductID = s.ProductID
            LEFT JOIN LimitedProducts l ON p.ProductID = l.ProductID
            WHERE p.IsActive = 1
        """)
        
        products = cursor.fetchall()
        return jsonify({"success": True, "products": products})
    except Exception as e:
        return jsonify({"success": False, "message": f"获取商品失败: {str(e)}"})
    finally:
        cursor.close()
        conn.close()

@app.route('/user/api/search_products')
def user_api_search_products():
    if session.get('role') != 'user':
        return jsonify({"success": False, "message": "权限不足"})
        
    keyword = request.args.get('keyword', '')
    if not keyword:
        return jsonify({"success": False, "message": "请输入搜索关键词"})
    
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor(dictionary=True)
    
    try:
        # 搜索商品名称包含关键词的商品
        cursor.execute("""
            SELECT p.ProductID, p.ProductName, p.Price, p.Category,
                   CASE 
                       WHEN p.Category = 'standard' THEN s.Stock
                       WHEN p.Category = 'limited' THEN l.StockLimits
                       ELSE NULL
                   END AS AvailableStock
            FROM Products p
            LEFT JOIN StandardProducts s ON p.ProductID = s.ProductID
            LEFT JOIN LimitedProducts l ON p.ProductID = l.ProductID
            WHERE p.IsActive = 1 AND p.ProductName LIKE %s
        """, (f'%{keyword}%',))
        
        products = cursor.fetchall()
        return jsonify({"success": True, "products": products})
    except Exception as e:
        return jsonify({"success": False, "message": f"搜索商品失败: {str(e)}"})
    finally:
        cursor.close()
        conn.close()

@app.route('/user/api/orders')
def user_api_orders():
    if session.get('role') != 'user':
        return jsonify({"success": False, "message": "权限不足"})
        
    user_id = session.get('userid')
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor(dictionary=True)
    
    try:
        # 查询用户的所有订单及详情
        cursor.execute("""
            SELECT o.OrderID, o.OrderTime, o.TotalPrice, o.Status,
                   p.ProductName, o.Quantity,o.ProductID
            FROM Orders o
            JOIN Products p ON o.ProductID = p.ProductID
            WHERE o.UserID = %s
            ORDER BY o.OrderTime DESC
        """, (user_id,))
        
        orders = cursor.fetchall()
        
        # 格式化日期时间
        for order in orders:
            if order['OrderTime']:
                order['OrderTime'] = order['OrderTime'].strftime('%Y-%m-%d %H:%M:%S')
        
        return jsonify({"success": True, "orders": orders})
    except Exception as e:
        return jsonify({"success": False, "message": f"获取订单失败: {str(e)}"})
    finally:
        cursor.close()
        conn.close()

@app.route('/user/api/profile')
def user_api_profile():
    if session.get('role') != 'user':
        return jsonify({})
    
    user_id = session.get('userid')
    
    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor(dictionary=True)
        
        # 查询用户信息
        cursor.execute("SELECT UserID, UserName, Phone FROM Users WHERE UserID = %s", (user_id,))
        user = cursor.fetchone()
        
        cursor.close()
        conn.close()
        
        return jsonify(user or {})
    except Exception as e:
        print(f"获取用户信息出错: {e}")
        return jsonify({})


@app.route('/admin/api/users')
def admin_api_users():
    if session.get('role') != 'admin':
        return jsonify([])
    
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor(dictionary=True)
    
    try:
        cursor.execute("SELECT UserID, UserName FROM Users WHERE Role = 'user'")
        return jsonify(cursor.fetchall())
    finally:
        cursor.close()
        conn.close()

@app.route('/admin/api/merchants')
def admin_api_merchants():
    if session.get('role') != 'admin':
        return jsonify([])
        
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor(dictionary=True)
    
    try:
        cursor.execute("""
            SELECT u.UserID, u.UserName, u.Phone, m.IsActive
            FROM Users u
            JOIN Merchants m ON u.UserID = m.UserID
            WHERE u.Role = 'merchant'
            ORDER BY u.UserName
        """)
        
        merchants = cursor.fetchall()
        return jsonify(merchants)
    except Exception as e:
        print(f"获取商家列表失败: {e}")
        return jsonify([])
    finally:
        cursor.close()
        conn.close()

@app.route('/admin/api/product-requests')
def admin_api_product_requests():
    if session.get('role') != 'admin':
        return jsonify([])
    
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor(dictionary=True)
    
    try:
        cursor.execute("""
            SELECT RequestID, ProductID, UserID, Type, ProductName
            FROM ProductRequests
            WHERE Status = 'pending'
        """)
        return jsonify(cursor.fetchall())
    finally:
        cursor.close()
        conn.close()

@app.route('/admin/api/pending-merchants')
def admin_api_pending_merchants():
    if session.get('role') != 'admin':
        return jsonify([])
    
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor(dictionary=True)
    
    try:
        cursor.execute("""
            SELECT u.UserID, u.UserName, u.Phone
            FROM Users u
            LEFT JOIN Merchants m ON u.UserID = m.UserID
            WHERE u.Role = 'merchant' AND m.LicenseNo IS NULL AND m.IsActive = 0
        """)
        return jsonify(cursor.fetchall())
    finally:
        cursor.close()
        conn.close()

@app.route('/admin/approve_product_request/<request_id>', methods=['POST'])
def approve_product_request(request_id):
    if session.get('role') != 'admin':
        return jsonify({"success": False, "error": "权限不足"})

    conn = None
    cursor = None

    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor(dictionary=True)

        # 获取请求详情
        cursor.execute("SELECT * FROM ProductRequests WHERE RequestID = %s", (request_id,))
        request_data = cursor.fetchone()

        if not request_data:
            return jsonify({"success": False, "error": "请求不存在"})

        product_id = request_data['ProductID']
        user_id = request_data['UserID']
        product_name = request_data['ProductName']
        price = request_data['Price']
        product_type = request_data['ProductType']
        request_type = request_data['Type']

        # 更新请求状态为已批准
        cursor.execute("UPDATE ProductRequests SET Status = 'approved' WHERE RequestID = %s", (request_id,))

        # 根据请求类型执行不同操作
        if request_type == 'add':
            # 检查商品是否已存在
            cursor.execute("SELECT * FROM Products WHERE ProductID = %s", (product_id,))
            product_exists = cursor.fetchone()
            
            if product_exists:
                # 商品已存在，只需更新状态（重新上架）
                cursor.execute("""
                    UPDATE Products 
                    SET IsActive = 1, ProductName = %s, Price = %s, Category = %s
                    WHERE ProductID = %s
                """, (product_name, price, product_type, product_id))
            else:
                # 商品不存在，插入新记录（首次上架）
                cursor.execute("""
                    INSERT INTO Products 
                    (ProductID, UserID, ProductName, Price, Category, IsActive)
                    VALUES (%s, %s, %s, %s, %s, 1)
                """, (product_id, user_id, product_name, price, product_type))
                
                # 根据商品类型插入子表记录
                if product_type == 'standard':
                    cursor.execute("""
                        INSERT INTO StandardProducts (ProductID, Stock)
                        VALUES (%s, %s)
                    """, (product_id, request_data['Stock']))
                    
                elif product_type == 'limited':
                    cursor.execute("""
                        INSERT INTO LimitedProducts (ProductID, StockLimits, ReleaseTime)
                        VALUES (%s, %s, %s)
                    """, (product_id, request_data['StockLimits'], request_data['ReleaseTime']))
                    
                elif product_type == 'custom':
                    cursor.execute("""
                        INSERT INTO CustomProducts (ProductID, DesignNotes, DueDate)
                        VALUES (%s, %s, %s)
                    """, (product_id, request_data['DesignNotes'], request_data['DueDate']))
        
        elif request_type == 'update':
            cursor.execute("CALL UpdateProductFromRequest(%s)", (request_id,))

            # # 更新主表
            # cursor.execute("""
            #     UPDATE Products 
            #     SET ProductName = %s, Price = %s,IsActive = 1
            #     WHERE ProductID = %s
            # """, (product_name, price, product_id))
            
            # # 根据商品类型更新子表
            # if product_type == 'standard':
            #     cursor.execute("""
            #         UPDATE StandardProducts 
            #         SET Stock = %s
            #         WHERE ProductID = %s
            #     """, (request_data['Stock'], product_id))
                
            # elif product_type == 'limited':
            #     cursor.execute("""
            #         UPDATE LimitedProducts 
            #         SET StockLimits = %s, ReleaseTime = %s
            #         WHERE ProductID = %s
            #     """, (request_data['StockLimits'], request_data['ReleaseTime'], product_id))
                
            # elif product_type == 'custom':
            #     cursor.execute("""
            #         UPDATE CustomProducts 
            #         SET DesignNotes = %s, DueDate = %s
            #         WHERE ProductID = %s
            #     """, (request_data['DesignNotes'], request_data['DueDate'], product_id))
                
        elif request_type == 'delete':
            # 更新商品状态为下架而不是物理删除
            cursor.execute("""
                UPDATE Products 
                SET IsActive = 0 
                WHERE ProductID = %s
            """, (product_id,))

        conn.commit()
        return jsonify({"success": True, "message": "商品请求已批准"})

    except Exception as e:
        if conn:
            conn.rollback()
        return jsonify({"success": False, "error": str(e)})

    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@app.route('/admin/reject_product_request/<int:request_id>', methods=['POST'])
def reject_product_request(request_id):
    if 'role' not in session or session['role'] != 'admin':
        return redirect(url_for('login'))

    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()

        # 更新商品请求的状态为 rejected
        cursor.execute("""
            UPDATE ProductRequests
            SET Status = 'rejected'
            WHERE RequestID = %s
        """, (request_id,))
        conn.commit()

        cursor.close()
        conn.close()

        return jsonify({"success": True, "message": "商品请求已拒绝"})
    except Exception as e:
        return jsonify({"success": False, "message": f"发生错误: {e}"})

@app.route('/admin/activate_merchant', methods=['POST'])
def activate_merchant():
    if session.get('role') != 'admin':
        return jsonify({"success": False, "message": "权限不足"})
    
    try:
        # 获取表单数据
        user_id = request.form.get('userid')
        license_no = request.form.get('licenseno')
        
        # 验证数据
        if not user_id or not license_no:
            return jsonify({"success": False, "message": "缺少必要参数"})
        
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()
        
        # 检查商家是否存在
        cursor.execute("SELECT * FROM Merchants WHERE UserID = %s", (user_id,))
        if not cursor.fetchone():
            cursor.close()
            conn.close()
            return jsonify({"success": False, "message": "商家不存在"})
        
        # 更新商家信息，设置激活状态和许可证号
        cursor.execute(
            "UPDATE Merchants SET IsActive = TRUE, LicenseNo = %s WHERE UserID = %s", 
            (license_no, user_id)
        )
        
        conn.commit()
        cursor.close()
        conn.close()
        
        return jsonify({"success": True, "message": "商家已激活，许可证信息已保存"})
    
    except Exception as e:
        return jsonify({"success": False, "message": f"激活失败: {str(e)}"})


@app.route('/admin/delete_merchant/<user_id>', methods=['POST'])
def delete_merchant(user_id):
    if session.get('role') != 'admin':
        return jsonify({"success": False, "message": "权限不足"})

    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()

    try:
        # 开始事务
        conn.start_transaction()
        
        # 1. 删除订单 - 使用JOIN查询关联商家的商品订单
        cursor.execute("""
            DELETE o FROM Orders o
            JOIN Products p ON o.ProductID = p.ProductID
            WHERE p.UserID = %s
        """, (user_id,))
        
        # 2. 删除商品请求
        cursor.execute("""
            DELETE FROM ProductRequests 
            WHERE UserID = %s
        """, (user_id,))
        
        # 3. 删除标准商品
        cursor.execute("""
            DELETE sp FROM StandardProducts sp
            JOIN Products p ON sp.ProductID = p.ProductID
            WHERE p.UserID = %s
        """, (user_id,))
        
        # 4. 删除限量商品
        cursor.execute("""
            DELETE lp FROM LimitedProducts lp
            JOIN Products p ON lp.ProductID = p.ProductID
            WHERE p.UserID = %s
        """, (user_id,))
        
        # 5. 删除定制商品
        cursor.execute("""
            DELETE cp FROM CustomProducts cp
            JOIN Products p ON cp.ProductID = p.ProductID
            WHERE p.UserID = %s
        """, (user_id,))
        
        # 6. 删除商品
        cursor.execute("""
            DELETE FROM Products 
            WHERE UserID = %s
        """, (user_id,))
        
        # 7. 删除商家信息
        cursor.execute("""
            DELETE m FROM Merchants m
            WHERE m.UserID = %s
        """, (user_id,))
        
        # 8. 删除用户账号
        cursor.execute("""
            DELETE u FROM Users u
            WHERE u.UserID = %s AND u.Role = 'merchant'
        """, (user_id,))
        
        # 提交事务
        conn.commit()
        return jsonify({"success": True, "message": "商家及其所有数据已成功删除"})
    
    except Exception as e:
        # 发生错误时回滚
        conn.rollback()
        return jsonify({"success": False, "message": f"删除失败: {str(e)}"})

    finally:
        cursor.close()
        conn.close()
@app.route('/merchant/profile')
def get_merchant_profile():
    if 'userid' not in session or session['role'] != 'merchant':
        return jsonify({"error": "未授权访问"}), 403
        
    merchant_id = session['userid']
    
    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor(dictionary=True)
        
        cursor.execute("""
            SELECT u.UserID, u.UserName, u.Phone, m.LicenseNo, m.IsActive
            FROM Users u
            JOIN Merchants m ON u.UserID = m.UserID
            WHERE u.UserID = %s
        """, (merchant_id,))
        
        profile = cursor.fetchone()
        return jsonify(profile)
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500
        
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()
if __name__ == '__main__':
    app.run(debug=True)
